package unsw.dungeon;

public interface Goal {
	
}
