package unsw.dungeon;

public class Treasure extends Item {

    public Treasure(int x, int y) {
        super(x, y);
    }

	@Override
	public void useItem(Player player) {
		// TODO Auto-generated method stub
		
	}
}