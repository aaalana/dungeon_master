package unsw.dungeon;

public interface Observer {

}
