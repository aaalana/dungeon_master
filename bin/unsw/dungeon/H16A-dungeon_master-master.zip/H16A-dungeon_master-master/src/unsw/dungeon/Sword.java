package unsw.dungeon;

public class Sword extends Item {
	
    public Sword(int x, int y) {
        super(x, y);
    }

	@Override
	public void useItem(Player player) {
		// TODO Auto-generated method stub
		
	}

}